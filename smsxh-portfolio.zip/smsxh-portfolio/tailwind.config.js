/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: { sans: ['"Space Grotesk"', "system-ui", "sans-serif"] },
      colors: { ink: "#000000", violet: "#8b5cf6", aqua: "#22d3ee" },
    },
  },
  plugins: [],
};
