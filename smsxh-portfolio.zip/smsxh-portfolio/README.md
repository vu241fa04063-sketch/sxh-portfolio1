# smsxh-portfolio

React + TypeScript + Vite + Tailwind CSS portfolio.

## Run locally
1. Install Node.js (LTS) from nodejs.org
2. In this folder: `npm install`
3. `npm run dev` and open the address it prints (usually http://localhost:5173)

Windows PowerShell blocking npm? Run once:
`Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned`

## Edit your content
Open `src/data.ts`. Replace every `[PLACEHOLDER ...]`, your links, skills, projects and education.
Resume: copy your PDF to `public/resume.pdf`, then set `resumeUrl: "/resume.pdf"`.

## Check it builds
`npm run build` (must finish with no errors before deploying)

## Put it on GitHub
1. Create a free account at github.com, click **New repository**, name it `smsxh-portfolio`, leave it empty.
2. In this folder run:
   ```
   git init
   git add .
   git commit -m "First commit"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/smsxh-portfolio.git
   git push -u origin main
   ```

## Deploy on Vercel
1. Sign up at vercel.com using **Continue with GitHub**.
2. Click **Add New → Project**, pick `smsxh-portfolio`, click **Import**.
3. Vercel detects Vite automatically (Build: `npm run build`, Output: `dist`). Click **Deploy**.
4. You get a free `*.vercel.app` link. Every `git push` redeploys automatically.
5. Custom domain (e.g. smsxh.dev): you must own it. Project → **Settings → Domains → Add**, then follow the DNS steps shown.

## Contact form
It validates input only. It is NOT connected to a server. To receive messages later, add a service
such as Formspree or a Vercel serverless function.
