import { FormEvent, useState } from "react";
import { profile, skillGroups, projects, education } from "./data";

const links = [
  ["About", "#about"], ["Skills", "#skills"], ["Projects", "#projects"],
  ["Education", "#education"], ["Resume", "#resume"], ["Contact", "#contact"],
];

const grad = "bg-gradient-to-r from-violet to-aqua";
const card = "rounded-2xl border border-white/10 bg-white/[0.03] p-6";

function Section({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} aria-labelledby={`${id}-h`} className="mx-auto max-w-5xl scroll-mt-24 px-6 py-20">
      <h2 id={`${id}-h`} className="mb-10 text-3xl font-bold text-white sm:text-4xl">{title}</h2>
      {children}
    </section>
  );
}

function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-black/80 backdrop-blur">
      <nav aria-label="Main" className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
        <a href="#top" className="font-bold text-white">{profile.handle}</a>
        <button
          className="rounded-lg border border-white/20 px-3 py-1.5 text-sm text-white md:hidden"
          aria-expanded={open} aria-controls="nav-links" onClick={() => setOpen(!open)}
        >
          {open ? "Close menu" : "Menu"}
        </button>
        <ul id="nav-links" className={`${open ? "flex" : "hidden"} absolute left-0 right-0 top-full flex-col gap-1 border-b border-white/10 bg-black p-4 md:static md:flex md:flex-row md:border-0 md:p-0`}>
          {links.map(([label, href]) => (
            <li key={href}>
              <a href={href} onClick={() => setOpen(false)} className="block rounded px-3 py-2 text-sm text-zinc-300 hover:text-aqua">{label}</a>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}

type Errors = Partial<Record<"name" | "email" | "message", string>>;

function ContactForm() {
  const [v, setV] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState<Errors>({});
  const [done, setDone] = useState(false);

  const validate = (): Errors => {
    const e: Errors = {};
    if (v.name.trim().length < 2) e.name = "Enter your name (at least 2 characters).";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email)) e.email = "Enter a valid email, like name@example.com.";
    if (v.message.trim().length < 10) e.message = "Write a message of at least 10 characters.";
    return e;
  };

  const submit = (ev: FormEvent) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    setDone(Object.keys(e).length === 0);
  };

  const mailto = `mailto:${profile.email}?subject=${encodeURIComponent("Portfolio message from " + v.name)}&body=${encodeURIComponent(v.message)}`;
  const field = "w-full rounded-lg border border-white/15 bg-black px-4 py-3 text-white placeholder:text-zinc-600";

  return (
    <form onSubmit={submit} noValidate className={`${card} space-y-5`}>
      {(["name", "email", "message"] as const).map((k) => (
        <div key={k}>
          <label htmlFor={k} className="mb-1.5 block text-sm font-medium text-white">
            {k === "name" ? "Your name" : k === "email" ? "Your email" : "Message"}
          </label>
          {k === "message" ? (
            <textarea id={k} rows={5} className={field} value={v[k]} onChange={(e) => setV({ ...v, [k]: e.target.value })}
              aria-invalid={!!errors[k]} aria-describedby={errors[k] ? `${k}-err` : undefined} />
          ) : (
            <input id={k} type={k === "email" ? "email" : "text"} className={field} value={v[k]}
              onChange={(e) => setV({ ...v, [k]: e.target.value })}
              aria-invalid={!!errors[k]} aria-describedby={errors[k] ? `${k}-err` : undefined} />
          )}
          {errors[k] && <p id={`${k}-err`} role="alert" className="mt-1.5 text-sm text-rose-400">{errors[k]}</p>}
        </div>
      ))}
      <button type="submit" className={`${grad} rounded-lg px-6 py-3 font-bold text-black`}>Check message</button>
      {done && (
        <p role="status" className="text-sm text-aqua">
          Message looks good. This form isn’t connected to a server yet, so{" "}
          <a className="underline" href={mailto}>open it in your email app</a> to send.
        </p>
      )}
    </form>
  );
}

export default function App() {
  return (
    <div id="top">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded focus:bg-white focus:px-4 focus:py-2 focus:text-black">
        Skip to content
      </a>
      <Header />
      <main id="main">
        <div className="relative overflow-hidden">
          <div aria-hidden className="orb pointer-events-none absolute -right-40 -top-40 h-[34rem] w-[34rem] rounded-full opacity-40 blur-3xl"
            style={{ background: "conic-gradient(from 0deg, #8b5cf6, #22d3ee, #8b5cf6)" }} />
          <section className="relative mx-auto max-w-5xl px-6 pb-24 pt-28" aria-labelledby="hero-h">
            <p className="mb-4 text-zinc-400">{profile.role}</p>
            <h1 id="hero-h" className={`${grad} bg-clip-text pb-2 text-6xl font-bold leading-tight text-transparent sm:text-8xl`}>
              {profile.handle}
            </h1>
            <p className="mt-6 max-w-xl text-lg text-zinc-300">{profile.tagline}</p>
            <div className="mt-10 flex flex-wrap gap-4">
              <a href="#projects" className={`${grad} rounded-lg px-6 py-3 font-bold text-black`}>View projects</a>
              <a href="#contact" className="rounded-lg border border-white/25 px-6 py-3 font-bold text-white hover:border-aqua">Contact me</a>
            </div>
          </section>
        </div>

        <Section id="about" title="About">
          <p className="max-w-2xl text-lg">
            [PLACEHOLDER: Write 2–3 sentences about who you are, what you’re learning, and what kind of work you want.]
          </p>
        </Section>

        <Section id="skills" title="Skills">
          <div className="grid gap-6 md:grid-cols-3">
            {skillGroups.map((g) => (
              <div key={g.title} className={card}>
                <h3 className="mb-4 font-bold text-white">{g.title}</h3>
                <ul className="flex flex-wrap gap-2">
                  {g.items.map((s) => (
                    <li key={s} className="rounded-full border border-violet/40 px-3 py-1 text-sm">{s}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </Section>

        <Section id="projects" title="Projects">
          <div className="grid gap-6 md:grid-cols-3">
            {projects.map((p) => (
              <article key={p.title} className={`${card} flex flex-col`}>
                <h3 className="text-xl font-bold text-white">{p.title}</h3>
                <p className="mt-3 flex-1">{p.description}</p>
                <ul className="mt-4 flex flex-wrap gap-2 text-xs text-aqua">
                  {p.tags.map((t) => <li key={t} className="rounded-full bg-aqua/10 px-2.5 py-1">{t}</li>)}
                </ul>
                <div className="mt-5 flex gap-4 text-sm">
                  {p.repo ? <a className="underline hover:text-aqua" href={p.repo} target="_blank" rel="noreferrer">Source code</a>
                    : <span className="text-zinc-500">Source code: add link</span>}
                  {p.demo && <a className="underline hover:text-aqua" href={p.demo} target="_blank" rel="noreferrer">Live demo</a>}
                </div>
              </article>
            ))}
          </div>
        </Section>

        <Section id="education" title="Education">
          <ol className="space-y-6 border-l border-violet/50 pl-6">
            {education.map((e) => (
              <li key={e.school}>
                <h3 className="font-bold text-white">{e.program}</h3>
                <p>{e.school}</p>
                <p className="text-sm text-zinc-500">{e.years}</p>
              </li>
            ))}
          </ol>
        </Section>

        <Section id="resume" title="Resume">
          {profile.resumeUrl ? (
            <a href={profile.resumeUrl} download className={`${grad} inline-block rounded-lg px-6 py-3 font-bold text-black`}>Download resume (PDF)</a>
          ) : (
            <p>Resume not added yet. Put a PDF in the <code className="text-aqua">public</code> folder and set <code className="text-aqua">resumeUrl</code> in <code className="text-aqua">src/data.ts</code>.</p>
          )}
        </Section>

        <Section id="contact" title="Contact">
          <div className="grid gap-8 md:grid-cols-2">
            <ContactForm />
            <ul className="space-y-3">
              <li><a className="underline hover:text-aqua" href={`mailto:${profile.email}`}>{profile.email}</a></li>
              <li><a className="underline hover:text-aqua" href={profile.github} target="_blank" rel="noreferrer">GitHub</a></li>
              <li><a className="underline hover:text-aqua" href={profile.linkedin} target="_blank" rel="noreferrer">LinkedIn</a></li>
            </ul>
          </div>
        </Section>
      </main>
      <footer className="border-t border-white/10 py-8 text-center text-sm text-zinc-500">
        © {new Date().getFullYear()} {profile.handle}
      </footer>
    </div>
  );
}
