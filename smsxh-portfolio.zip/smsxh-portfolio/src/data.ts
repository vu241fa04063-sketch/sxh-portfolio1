// ✏️ EDIT THIS FILE to change your portfolio. Everything marked [PLACEHOLDER] is unconfirmed.

export const profile = {
  name: "[PLACEHOLDER: Your Name]",
  handle: "smsxh.dev",
  role: "Full-Stack Developer",
  tagline: "[PLACEHOLDER: One sentence about what you build and who you build it for.]",
  email: "your-email@example.com", // [PLACEHOLDER]
  github: "https://github.com/your-username", // [PLACEHOLDER]
  linkedin: "https://www.linkedin.com/in/your-profile", // [PLACEHOLDER]
  resumeUrl: "", // Put your PDF in /public (e.g. /resume.pdf) then set "/resume.pdf". Empty = button disabled.
};

export const skillGroups: { title: string; items: string[] }[] = [
  { title: "Frontend", items: ["React", "TypeScript", "Tailwind CSS", "HTML & CSS"] },
  { title: "Backend", items: ["Node.js", "REST APIs", "[PLACEHOLDER]"] },
  { title: "Data & Tools", items: ["SQL", "Git & GitHub", "[PLACEHOLDER]"] },
];

export type Project = { title: string; description: string; tags: string[]; repo: string; demo: string };

export const projects: Project[] = [
  {
    title: "React Product App",
    description: "A product list built with React components, props and map(). Replace with your own description.",
    tags: ["React", "JavaScript"],
    repo: "", // [PLACEHOLDER] add your GitHub repo URL
    demo: "",
  },
  {
    title: "[PLACEHOLDER: Project Two]",
    description: "[PLACEHOLDER: What it does, the problem it solves, and your role.]",
    tags: ["TypeScript", "Node.js"],
    repo: "",
    demo: "",
  },
  {
    title: "[PLACEHOLDER: Project Three]",
    description: "[PLACEHOLDER: What it does, the problem it solves, and your role.]",
    tags: ["Full-stack"],
    repo: "",
    demo: "",
  },
];

export const education: { school: string; program: string; years: string }[] = [
  { school: "[PLACEHOLDER: College / University]", program: "[PLACEHOLDER: Degree and major]", years: "[PLACEHOLDER: Start – End]" },
];
